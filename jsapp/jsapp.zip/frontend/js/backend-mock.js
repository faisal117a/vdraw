
(function () {
    console.log("%c VDraw In-Browser Backend Initialized ", "background: #4f46e5; color: white; padding: 4px; border-radius: 4px;");

    // ==========================================
    // STATE STORAGE
    // ==========================================
    const DB = {
        tree: {
            sessions: { "default": { root_id: null, nodes: {}, stats: null } },
            configs: { "default": { type: 'bst', root_value: 'Root' } }
        },
        graph: {
            sessions: { "default": { nodes: {}, adjacency_list: {}, config: { directed: true, weighted: false }, stats: null } }
        }
    };

    function uuidv4() {
        return 'xxxxxxxx'.replace(/[xy]/g, function (c) {
            var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
            return v.toString(16);
        });
    }

    // ==========================================
    // STATS ENGINE
    // ==========================================
    const StatsEngine = {
        calculate: function (payload) {
            const data = payload.data.sort((a, b) => a - b);
            const n = data.length;
            if (n === 0) throw new Error("No data");

            // Basic
            const sum = data.reduce((a, b) => a + b, 0);
            const mean = sum / n;
            const mid = Math.floor(n / 2);
            const median = n % 2 !== 0 ? data[mid] : (data[mid - 1] + data[mid]) / 2;
            const min = data[0];
            const max = data[n - 1];
            const range = max - min;

            // Mode
            const freq = {};
            let maxFreq = 0;
            data.forEach(v => { freq[v] = (freq[v] || 0) + 1; if (freq[v] > maxFreq) maxFreq = freq[v]; });
            const mode = Object.keys(freq).filter(k => freq[k] === maxFreq && maxFreq > 1).map(Number);

            // Variance
            const variance = data.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / (payload.is_sample ? n - 1 : n);
            const std_dev = Math.sqrt(variance);

            // Quartiles
            const q1 = n >= 4 ? data[Math.floor(n * 0.25)] : min;
            const q3 = n >= 4 ? data[Math.floor(n * 0.75)] : max;
            const iqr = q3 - q1;

            // Outliers
            const low = q1 - 1.5 * iqr;
            const high = q3 + 1.5 * iqr;
            const outliers = data.filter(x => x < low || x > high);

            // Regression
            let regression = null;
            if (payload.regression_type && payload.x_data && payload.y_data) {
                const X = payload.x_data;
                const Y = payload.y_data;
                if (X.length === Y.length && X.length > 1) {
                    if (payload.regression_type === 'linear') {
                        regression = this.linearRegression(X, Y);
                    } else if (payload.regression_type === 'logistic') {
                        regression = this.logisticRegression(X, Y);
                    }
                }
            }

            return {
                mean, median, mode, variance, std_dev, range,
                quartiles: { q1, q3 }, iqr, outliers,
                explanations: [
                    { title: "Mean", steps: [{ text: `Sum / N`, latex: `\\mu = ${mean.toFixed(2)}` }], result: mean.toFixed(2) },
                    { title: "Standard Deviation", steps: [{ text: "Sqrt(Variance)", latex: `\\sigma = ${std_dev.toFixed(2)}` }], result: std_dev.toFixed(2) }
                ],
                regression
            };
        },

        linearRegression: function (x, y) {
            const n = x.length;
            const sumX = x.reduce((a, b) => a + b, 0); const sumY = y.reduce((a, b) => a + b, 0);
            const sumXY = x.reduce((a, b, i) => a + b * y[i], 0); const sumXX = x.reduce((a, b) => a + b * b, 0);
            const slope = (n * sumXY - sumX * sumY) / (n * sumXX - sumX * sumX);
            const intercept = (sumY - slope * sumX) / n;
            const yMean = sumY / n;
            const ssTot = y.reduce((a, b) => a + Math.pow(b - yMean, 2), 0);
            const ssRes = y.reduce((a, b, i) => a + Math.pow(b - (slope * x[i] + intercept), 2), 0);
            return { slope, intercept, r2_score: 1 - (ssRes / ssTot), formula: `y = ${slope.toFixed(4)}x + ${intercept.toFixed(4)}` };
        },

        logisticRegression: function (x, y) {
            let m = 0, b = 0, lr = 0.01;
            const xMax = Math.max(...x) || 1;
            const xNorm = x.map(v => v / xMax);
            for (let i = 0; i < 1000; i++) {
                for (let j = 0; j < xNorm.length; j++) {
                    const z = m * xNorm[j] + b;
                    const pred = 1 / (1 + Math.exp(-z));
                    const err = pred - y[j];
                    m -= lr * err * xNorm[j];
                    b -= lr * err;
                }
            }
            let correct = 0;
            xNorm.forEach((xv, i) => { if ((1 / (1 + Math.exp(-(m * xv + b))) >= 0.5 ? 1 : 0) === y[i]) correct++; });
            return { accuracy: correct / x.length, classes: ["0", "1"], coefficients: [m / xMax], intercept: b, formula: `p(x) = sigmoid...` };
        }
    };

    // ==========================================
    // TGDRAW ENGINE
    // ==========================================
    class TreeEngine {
        constructor(sid = 'default') { this.sid = sid; this.state = DB.tree.sessions[sid]; this.config = DB.tree.configs[sid]; }
        reset(config) {
            this.state.root_id = null; this.state.nodes = {}; DB.tree.configs[this.sid] = config; this.config = config;
            const rootId = uuidv4().substring(0, 8);
            this.state.nodes[rootId] = { id: rootId, value: config.root_value, children: [], left: null, right: null };
            this.state.root_id = rootId; this.calculateStats();
            return this.state;
        }
        addNode(parentId, value, direction) {
            const parent = this.state.nodes[parentId]; if (!parent) throw new Error("Parent not found");
            const type = this.config.type;
            if (['binary', 'bst', 'avl'].includes(type) && !direction) throw new Error("Direction required");
            if (direction === 'left' && parent.left) throw new Error("Left child exists");
            if (direction === 'right' && parent.right) throw new Error("Right child exists");

            if (['bst', 'avl'].includes(type)) {
                let pVal = parseFloat(parent.value);
                let nVal = parseFloat(value);
                if (isNaN(pVal)) pVal = parent.value; if (isNaN(nVal)) nVal = value;
                const err = type === 'avl' ? "AVL Constraint" : "BST Rule Violation";
                if (direction === 'left' && !(nVal < pVal)) throw new Error(`${err}: ${nVal} must be < ${pVal}`);
                if (direction === 'right' && !(nVal > pVal)) throw new Error(`${err}: ${nVal} must be > ${pVal}`);
            }

            const newId = uuidv4().substring(0, 8);
            this.state.nodes[newId] = { id: newId, value: value, children: [], left: null, right: null };
            if (type === 'generic') parent.children.push(newId);
            else { if (direction === 'left') parent.left = newId; else parent.right = newId; parent.children = [parent.left, parent.right].filter(x => x); }

            this.calculateStats();
            if (type === 'avl' && !this.state.stats.is_balanced) {
                delete this.state.nodes[newId];
                if (type === 'generic') parent.children.pop(); else { if (direction === 'left') parent.left = null; else parent.right = null; parent.children = [parent.left, parent.right].filter(x => x); }
                this.calculateStats();
                throw new Error("AVL Violation: Tree imbalance (Height Diff > 1).");
            }
            return this.state;
        }
        calculateStats() {
            if (!this.state.root_id) return;
            let q = [{ id: this.state.root_id, level: 0 }], maxH = 0, leaves = [];
            while (q.length) {
                const { id, level } = q.shift(); const n = this.state.nodes[id];
                if (level > maxH) maxH = level;
                const children = (this.config.type === 'generic') ? n.children : [n.left, n.right].filter(x => x);
                if (!children.length) leaves.push(n.value);
                children.forEach(c => q.push({ id: c, level: level + 1 }));
            }
            const balanced = (nid) => {
                if (!nid) return [0, true];
                const n = this.state.nodes[nid];
                const [lh, lb] = balanced(n.left), [rh, rb] = balanced(n.right);
                return [1 + Math.max(lh, rh), lb && rb && Math.abs(lh - rh) <= 1];
            };
            this.state.stats = { total_nodes: Object.keys(this.state.nodes).length, height: maxH, leaf_count: leaves.length, leaves, is_balanced: ['binary', 'bst', 'avl'].includes(this.config.type) ? balanced(this.state.root_id)[1] : true };
        }
        traverse(type) {
            const steps = []; const n = this.state.nodes; const rid = this.state.root_id;
            const log = (id, act, desc) => steps.push({ node_id: id, action: act, description: desc });
            if (!rid) return [];
            const visit = (id) => log(id, 'visit', `Visit ${n[id].value}`);
            const explore = (id, msg) => log(id, 'explore', msg);

            if (type === 'bfs') {
                let q = [rid]; log(rid, 'enqueue', 'Start');
                while (q.length) { const c = q.shift(); visit(c); const kids = (this.config.type === 'generic') ? n[c].children : [n[c].left, n[c].right].filter(x => x); kids.forEach(k => { q.push(k); log(k, 'enqueue', 'Queue'); }); }
            } else if (type === 'preorder' || type === 'dfs') {
                const pre = (id) => { if (!id) return; visit(id); if (this.config.type === 'generic') n[id].children.forEach(c => { explore(c, 'Child'); pre(c); }); else { if (n[id].left) { explore(n[id].left, 'Left'); pre(n[id].left); } if (n[id].right) { explore(n[id].right, 'Right'); pre(n[id].right); } } }; pre(rid);
            } else if (type === 'postorder') {
                const post = (id) => { if (!id) return; if (this.config.type === 'generic') n[id].children.forEach(c => { explore(c, 'Child'); post(c) }); else { if (n[id].left) { explore(n[id].left, 'Left'); post(n[id].left); } if (n[id].right) { explore(n[id].right, 'Right'); post(n[id].right); } } visit(id); }; post(rid);
            } else if (type === 'inorder') {
                const ino = (id) => { if (!id) return; const nd = n[id]; if (nd.left) { explore(nd.left, 'Left'); ino(nd.left); } visit(id); if (nd.right) { explore(nd.right, 'Right'); ino(nd.right); } }; ino(rid);
            }
            return steps;
        }
    }

    class GraphEngine {
        constructor(sid = 'default') { this.sid = sid; this.state = DB.graph.sessions[sid]; }
        create(cfg) { this.state.nodes = {}; this.state.adjacency_list = {}; this.state.config = cfg; this.calc(); return this.state; }
        addNode(id, v) { if (this.state.nodes[id]) throw new Error("Exists"); this.state.nodes[id] = { id, value: v }; this.state.adjacency_list[id] = []; this.calc(); return this.state; }
        addEdge(s, t, w) {
            const adj = this.state.adjacency_list; if (adj[s].find(e => e.target === t)) throw new Error("Exists");
            adj[s].push({ target: t, weight: w }); if (!this.state.config.directed && !adj[t].find(e => e.target === s)) adj[t].push({ target: s, weight: w, bidirectional: true });
            this.calc(); return this.state;
        }
        removeEdge(s, t) {
            this.state.adjacency_list[s] = this.state.adjacency_list[s].filter(e => e.target !== t);
            if (!this.state.config.directed) this.state.adjacency_list[t] = this.state.adjacency_list[t].filter(e => e.target !== s);
            this.calc(); return this.state;
        }
        calc() {
            const n = Object.keys(this.state.nodes), adj = this.state.adjacency_list, d = this.state.config.directed, deg = {}; let eCount = 0;
            n.forEach(i => { const out = (adj[i] || []).length; let inc = 0; if (d) n.forEach(o => { if ((adj[o] || []).find(e => e.target == i)) inc++; }); else inc = out; deg[i] = { total: out + (d ? inc : 0), in: inc, out }; eCount += out; });
            this.state.stats = { total_vertices: n.length, total_edges: d ? eCount : eCount / 2, degrees: deg };
        }
        runAlgo(algo, start) {
            const steps = [], n = this.state.nodes, adj = this.state.adjacency_list; const log = (i, a, d) => steps.push({ node_id: i, action: a, description: d });
            if (algo === 'bfs') {
                const q = [start], vis = new Set([start]); log(start, 'enqueue', 'Begin');
                while (q.length) { const c = q.shift(); log(c, 'visit', 'Visit'); (adj[c] || []).forEach(e => { if (!vis.has(e.target)) { vis.add(e.target); q.push(e.target); log(e.target, 'enqueue', 'Queue'); } }); }
            } else if (algo === 'dfs') {
                const vis = new Set(); const dfs = (curr) => { vis.add(curr); log(curr, 'visit', 'Visit'); (adj[curr] || []).forEach(e => { if (!vis.has(e.target)) { log(e.target, 'explore', 'To'); dfs(e.target); } }); }; dfs(start);
            } else if (algo === 'dijkstra') {
                const dist = {}, pq = [{ id: start, d: 0 }], vis = new Set(); Object.keys(n).forEach(k => dist[k] = Infinity); dist[start] = 0; log(start, 'enqueue', 'Init');
                while (pq.length) { pq.sort((a, b) => a.d - b.d); const { id, d } = pq.shift(); if (vis.has(id)) continue; vis.add(id); log(id, 'visit', `Dist: ${d}`); (adj[id] || []).forEach(e => { const w = e.weight || 1; if (dist[id] + w < dist[e.target]) { dist[e.target] = dist[id] + w; pq.push({ id: e.target, d: dist[e.target] }); log(e.target, 'enqueue', `Update ${dist[e.target]}`); } }); }
            }
            return steps;
        }
    }

    // ==========================================
    // PDRAW ENGINE
    // ==========================================
    const PDRAW_CATALOG = {
        structures: [
            {
                id: "stack", label: "Stack (LIFO)", implementations: ["list", "collections.deque"], operations: [
                    { id: "push", label: "Push", params: [{ name: "value", type: "any" }], complexity: "O(1)" },
                    { id: "pop", label: "Pop", params: [], complexity: "O(1)" },
                    { id: "peek", label: "Peek", params: [], complexity: "O(1)" },
                    { id: "is_empty", label: "Is Empty?", params: [], complexity: "O(1)" }
                ]
            },
            {
                id: "queue", label: "Queue (FIFO)", implementations: ["list", "collections.deque", "queue.Queue"], operations: [
                    { id: "enqueue", label: "Enqueue", params: [{ name: "value", type: "any" }], complexity: "O(1)" },
                    { id: "dequeue", label: "Dequeue", params: [], complexity: "O(1)" },
                    { id: "front", label: "Front", params: [], complexity: "O(1)" },
                    { id: "rear", label: "Rear", params: [], complexity: "O(1)" }
                ]
            },
            {
                id: "list", label: "List (Array)", implementations: ["list"], operations: [
                    { id: "append", label: "Append", params: [{ name: "value", type: "any" }], complexity: "O(1)" },
                    { id: "extend", label: "Extend", params: [{ name: "iterable", type: "any" }], complexity: "O(k)" },
                    { id: "insert", label: "Insert", params: [{ name: "index", type: "int" }, { name: "value", type: "any" }], complexity: "O(n)" },
                    { id: "pop", label: "Pop Index", params: [{ name: "index", type: "int", required: false }], complexity: "O(k)" },
                    { id: "remove", label: "Remove Value", params: [{ name: "value", type: "any" }], complexity: "O(n)" },
                    { id: "clear", label: "Clear", params: [], complexity: "O(1)" },
                    { id: "index", label: "Index", params: [{ name: "value", type: "any" }], complexity: "O(n)" },
                    { id: "count", label: "Count", params: [{ name: "value", type: "any" }], complexity: "O(n)" },
                    { id: "sort", label: "Sort", params: [], complexity: "O(n log n)" },
                    { id: "reverse", label: "Reverse", params: [], complexity: "O(n)" },
                    { id: "slice", label: "Slice", params: [{ name: "start", type: "int" }, { name: "stop", type: "int" }, { name: "step", type: "int" }], complexity: "O(k)" }
                ]
            },
            {
                id: "tuple", label: "Tuple", implementations: ["tuple"], operations: [
                    { id: "index", label: "Index", params: [{ name: "value", type: "any" }], complexity: "O(n)" },
                    { id: "count", label: "Count", params: [{ name: "value", type: "any" }], complexity: "O(n)" },
                    { id: "len", label: "Length", params: [], complexity: "O(1)" },
                    { id: "slice", label: "Slice", params: [{ name: "start", type: "int" }, { name: "stop", type: "int" }, { name: "step", type: "int" }], complexity: "O(k)" }
                ]
            }
        ]
    };

    const PDrawSimulator = {
        simulate: function (req) {
            const stype = req.structure;
            const impl = req.implementation;
            // Deep copy logic
            let state = [...req.initial_values];

            // Diagram helper
            const getDiag = (s) => ({ type: stype, items: [...(Array.isArray(s) ? s : [])], front: 0, rear: s.length - 1 });

            const initial = { print: JSON.stringify(state), diagram: getDiag(state) };
            const steps = [];

            let currentState = [...state]; // mimic list

            req.operations.forEach((op, idx) => {
                const opName = op.op;
                const args = op.args || {};
                const val = args.value;
                let printState = "";
                let expl = "";
                let error = null;
                let status = "ok";
                let complexity = "O(1)";

                try {
                    const style = t => `<span class="font-bold text-yellow-300">${t}</span>`;

                    if (stype === 'stack') {
                        if (opName === 'push') { currentState.push(val); expl = `Pushed ${val}.`; }
                        else if (opName === 'pop') { if (!currentState.length) throw "Empty"; const p = currentState.pop(); expl = `Popped ${p}.`; }
                        else if (opName === 'peek') { if (!currentState.length) throw "Empty"; expl = `Top: ${currentState[currentState.length - 1]}`; }
                        else if (opName === 'is_empty') { expl = `Empty? ${currentState.length === 0}`; }
                    }
                    else if (stype === 'queue') {
                        if (opName === 'enqueue') { currentState.push(val); expl = `Enqueued ${val}.`; }
                        else if (opName === 'dequeue') {
                            if (!currentState.length) throw "Empty";
                            // Deque impl optimization check? In Mock, assume efficient if impl='deque'
                            const p = currentState.shift(); expl = `Dequeued ${p}.`;
                        }
                        else if (opName === 'front') { if (!currentState.length) throw "Empty"; expl = `Front: ${currentState[0]}`; }
                        else if (opName === 'rear') { if (!currentState.length) throw "Empty"; expl = `Rear: ${currentState[currentState.length - 1]}`; }
                    }
                    else if (stype === 'list') {
                        if (opName === 'append') { currentState.push(val); expl = `Appended ${val}`; }
                        else if (opName === 'insert') { currentState.splice(args.index, 0, val); expl = `Inserted at ${args.index}`; complexity = "O(n)"; }
                        else if (opName === 'remove') {
                            const i = currentState.indexOf(val);
                            if (i === -1) throw "Not found"; currentState.splice(i, 1); expl = `Removed ${val}`; complexity = "O(n)";
                        }
                        else if (opName === 'pop') {
                            if (args.index !== undefined) { currentState.splice(args.index, 1); expl = `Popped at ${args.index}`; complexity = "O(n)"; }
                            else { currentState.pop(); expl = "Popped last"; }
                        }
                        else if (opName === 'index') { const i = currentState.indexOf(val); if (i === -1) throw "Not found"; expl = `Index: ${i}`; complexity = "O(n)"; }
                        else if (opName === 'count') { const c = currentState.filter(x => x == val).length; expl = `Count: ${c}`; complexity = "O(n)"; }
                        else if (opName === 'sort') { currentState.sort((a, b) => (typeof a === 'number' ? a - b : String(a).localeCompare(String(b)))); expl = "Sorted"; complexity = "O(n log n)"; }
                        else if (opName === 'reverse') { currentState.reverse(); expl = "Reversed"; complexity = "O(n)"; }
                        else if (opName === 'slice') {
                            // Manual slice for step emulation
                            const start = args.start || 0; const stop = args.stop !== undefined ? args.stop : currentState.length; const step = args.step || 1;
                            const res = [];
                            for (let i = start; (step > 0 ? i < stop : i > stop); i += step) { if (currentState[i] !== undefined) res.push(currentState[i]); }
                            expl = `Sliced: ${JSON.stringify(res)}`;
                            // Slice doesn't mutate state in python logic
                        }
                        else if (opName === 'extend') {
                            const it = Array.isArray(args.iterable) ? args.iterable : [args.iterable];
                            currentState.push(...it); expl = `Extended with ${JSON.stringify(it)}`; complexity = "O(k)";
                        }
                        else if (opName === 'clear') { currentState = []; expl = "Cleared"; }
                    }
                    else if (stype === 'tuple') {
                        if (opName === 'index') { const i = currentState.indexOf(val); if (i === -1) throw "Not found"; expl = `Index: ${i}`; complexity = "O(n)"; }
                        else if (opName === 'count') { const c = currentState.filter(x => x == val).length; expl = `Count: ${c}`; complexity = "O(n)"; }
                        else if (opName === 'len') { expl = `Length: ${currentState.length}`; }
                        else if (opName === 'slice') { expl = "Sliced (Immutable)"; }
                    }

                    printState = JSON.stringify(currentState);

                } catch (e) {
                    error = String(e);
                    status = "error";
                    expl = `Error: ${error}`;
                }

                steps.push({
                    index: idx + 1,
                    operation: `${opName}(${JSON.stringify(args).replace(/"/g, '')})`,
                    status,
                    print_output: printState || String(state),
                    explanation: expl,
                    complexity,
                    diagram: getDiag(currentState),
                    error_msg: error
                });
            });

            return { initial, steps };
        }
    };


    // ==========================================
    // DATA PARSER
    // ==========================================
    async function parseFileUpload(formData) {
        const file = formData.get('file');
        const text = await file.text();
        const lines = text.trim().split(/\r?\n/);
        if (lines.length < 2) throw new Error("File empty");
        const delim = lines[0].includes('\t') ? '\t' : ',';
        const headers = lines[0].split(delim).map(s => s.trim().replace(/^"|"$/g, ''));
        const cols = {}; headers.forEach(h => cols[h] = []);
        for (let i = 1; i < lines.length; i++) {
            const row = lines[i].split(delim);
            headers.forEach((h, j) => {
                let val = row[j] ? row[j].trim().replace(/^"|"$/g, '') : null;
                if (val && !isNaN(Number(val))) val = Number(val);
                cols[h].push(val);
            });
        }
        const numCols = headers.filter(h => cols[h].filter(x => typeof x === 'number').length > cols[h].length * 0.5);
        return { full_data: cols, columns: headers, numeric_columns: numCols, summary: { rows: lines.length - 1 } };
    }

    // ==========================================
    // FETCH INTERCEPTOR
    // ==========================================
    const originalFetch = window.fetch;
    const originalFetch = window.fetch;
    window.fetch = async function (url, options) {
        if ((typeof url === 'string') && (url.includes('127.0.0.1:8000') || url.startsWith('/api'))) {
            await new Promise(r => setTimeout(r, 100)); // Latency
            try {
                let responseData = null;
                // Parse Body safely
                let body = {};
                if (options && options.body) {
                    if (options.body instanceof FormData) {
                        // Pass FormData directly if expecting one (like in parseFileUpload)
                        body = options.body;
                    } else if (typeof options.body === 'string') {
                        try { body = JSON.parse(options.body); } catch (e) { body = {}; }
                    }
                }

                // ROUTING
                // STATS
                if (url.includes('/api/stats/calculate')) responseData = StatsEngine.calculate(body);
                // For parseFileUpload, use the raw FormData in options.body, NOT the parsed JSON empty object if it was a string
                else if (url.includes('/api/data/parse')) responseData = await parseFileUpload(options.body); // Use raw FormData

                // TGDRAW
                else if (url.includes('/api/tg/tree/create-root')) responseData = { success: true, data: new TreeEngine().reset({ type: body.type, root_value: body.value }) };
                else if (url.includes('/api/tg/tree/add-node')) responseData = { success: true, data: new TreeEngine().addNode(body.parent_id, body.value, body.direction) };
                else if (url.includes('/api/tg/tree/traverse')) responseData = { success: true, data: new TreeEngine().traverse(body.type) };
                else if (url.includes('/api/tg/graph/create')) responseData = { success: true, data: new GraphEngine().create(body) };
                else if (url.includes('/api/tg/graph/add-node')) responseData = { success: true, data: new GraphEngine().addNode(body.id, body.value) };
                else if (url.includes('/api/tg/graph/add-edge')) responseData = { success: true, data: new GraphEngine().addEdge(body.source, body.target, body.weight) };
                else if (url.includes('/api/tg/graph/remove-edge')) responseData = { success: true, data: new GraphEngine().removeEdge(body.source, body.target) };
                else if (url.includes('/api/tg/graph/run-algorithm')) responseData = { success: true, data: new GraphEngine().runAlgo(body.algorithm, body.start_node) };

                // PDRAW
                else if (url.includes('/api/pdraw/catalog')) responseData = PDRAW_CATALOG;
                else if (url.includes('/api/pdraw/simulate')) responseData = PDrawSimulator.simulate(body);

                if (responseData) return new Response(JSON.stringify(responseData), { status: 200, headers: { 'Content-Type': 'application/json' } });

            } catch (err) {
                console.error("[MockServer] Error", err);
                return new Response(JSON.stringify({ error: err.message, success: false }), { status: 400 });
            }
        }
        return originalFetch(url, options);
    };

})();
